package com.cg.spring.mvc.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.mvc.beans.Student;
import com.cg.spring.mvc.repo.StudentRepository;
@Service
@Transactional
public class StudentServiceImpl implements StudentService{

	@Autowired
	StudentRepository repo;
	public StudentRepository getRepo() {
		return repo;
	}
	public void setRepo(StudentRepository repo) {
		this.repo = repo;
	}
	@Override
	public Student addStudent(Student student) {
		return repo.addStudent(student);
	}
	/*@Override
	public List<Student> getStudentList(String city) {
		return repo.getStudentList(city);
		}*/
	/*@Override
	public List<String> getcityList() {
		// TODO Auto-generated method stub
		return repo.getCityList();
	}*/
	@Override
	public List<Student> getStudentList() {
		return repo.getStudentList();
	}
	/*@Override
	public void updateStudent(Student student) {
		// TODO Auto-generated method stub
		repo.updateStudent(student);
	}
	@Override
	public void deleteStudent(int id) {
		// TODO Auto-generated method stub
		repo.deleteStudent(id);
	}
	@Override
	public Student findStudent(int sid) {
		Student student= repo.findStudent(sid);
		System.out.println(student.getStudentId()+ student.getFirstName());
		return student;
	}*/
}
