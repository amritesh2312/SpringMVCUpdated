package com.cg.spring.mvc.controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.spring.mvc.beans.Student;
import com.cg.spring.mvc.service.StudentService;

@Controller
public class HomeController {

	@Autowired 
	StudentService service ;
	public StudentService getService() {
		return service;
	}
	public void setService(StudentService service) {
		this.service = service;
	}
	@RequestMapping("index")
	public String getIndexPage(Model model){
		List<Student> list= service.getStudentList();
		//System.out.println(list);
		model.addAttribute("studentList", list);
		return "index";
	}
	 
	@RequestMapping("showLoginPage")
	public String getLoginPage(){
		return "Login"; 
	}
	@RequestMapping("loginAction")
	public String validateUser(Model model ,
			  @RequestParam("user") String uname,
			  @RequestParam("pwd")String pass){
		if(uname.equals("Yogini") && pass.equals("corp123"))
		{
		model.addAttribute("successMsg",
				"Welcome to Home Page");
		model.addAttribute("userName", uname);
		return "Home";
		}
		else
		{
			model.addAttribute
			("errorMsg", "Invalid Username/Password");
			return "Error";
		}
	}
	
	@RequestMapping("showRegistrationPage")
	public String getRegistrationPage(Model model){
		Student student= new Student();
		model.addAttribute("studentBean", student);
		return "RegistrationPage";
		}
	@RequestMapping("registerAction")
	public String registerUser(Model model,
			@ModelAttribute("studentBean")
	@Valid Student student,BindingResult result){
		if(result.hasErrors())
		{
			return "RegistrationPage";
		}else{
			student= service.addStudent(student);
		model.addAttribute("student", student);
		model.addAttribute("successMsg", "Student Added ");
		return "Success";
	}
	}
/*	@RequestMapping("showStudentListCitywise")
	public String getCityPage(Model model){
		List<String> list= service.getcityList();
		model.addAttribute("cityList", list);
		return "AcceptCity";
	}*/
/*@RequestMapping("getStudentList")
	public String showStudentList(Model model, 
			@RequestParam("city") String city){
		List<Student> list=service.getStudentList(city);
		model.addAttribute("studentList", list);
		List<String> citylist= service.getcityList();
		model.addAttribute("cityList", citylist);
		
		return "AcceptCity";
	}*/
/*@RequestMapping("updateStudent.obj")
	public String updateStudent(Model model, @RequestParam("id") int sid){
	Student student= service.findStudent(sid);
	System.out.println("in controller..."+student.getStudentId());
	model.addAttribute("student", student);
		return "UpdateStudentDetails";
		
	}
@RequestMapping("updateAction")
	public String updateStudentAction(Model model , @ModelAttribute("student") Student student){
			service.updateStudent(student);
		return "index";
	}
@RequestMapping("deleteStudent")
	public String deleteStudent(@RequestParam("id") int sid){
		service.deleteStudent(sid);
		return "index";
}*/
	
}



